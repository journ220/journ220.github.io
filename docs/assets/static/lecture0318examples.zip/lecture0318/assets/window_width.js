'use strict';

const docReady = function(func) {
  // https://stackoverflow.com/a/9899701
    // see if DOM is already available
  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    // call on next available tick
    setTimeout(func, 1);
  } else {
    document.addEventListener('DOMContentLoaded', func);
  }
};

const getWidth = () => {
  document.getElementById('width').innerHTML = `${ window.innerWidth }px`;
};


docReady(() => {
  getWidth();

  window.addEventListener('resize', () => {
    getWidth();
  });
});
