document.querySelector("h1").style.color = "blue";
