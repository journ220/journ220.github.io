// Use two slashes at the beginning of a line to write a comment

/*

Use a slash and asterisk for a multi-line comment.

*/