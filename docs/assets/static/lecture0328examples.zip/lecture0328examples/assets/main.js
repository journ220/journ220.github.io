// Use two slashes at the beginning of a line to write a comment

// let currentYear = new Date().getFullYear();
// document.getElementById('copyright-year').innerHTML = currentYear;


