// document.getElementById('alert').addEventListener('click', function(event) {
//   alert('Hello!');
// });

// console.log(document.getElementById('alrt'));

// console.log(document.getElementById('alert'));

// console.log(document.getElementById('alert').clientWidth);

// console.log(document.getElementById('alert').clientHeight);