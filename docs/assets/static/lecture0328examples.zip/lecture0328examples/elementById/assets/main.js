// document.getElementById('replace').innerHTML = 'Replace all of the text'


// You can see all the different methods to access and change an element here: 
// https://developer.mozilla.org/en-US/docs/Web/API/Document
