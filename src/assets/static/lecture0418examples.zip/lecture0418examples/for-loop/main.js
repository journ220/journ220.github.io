// button
const addBorder = document.getElementById('addBorder');

// all the images with the class "outline"
const outlineImages = document.getElementsByClassName('outline');

addBorder.addEventListener('click', function(e) {
  // when the button is clicked
  // iterate over every element in outlineImages
  for (let i=0; i < outlineImages.length; i++) {
    outlineImages[i].style.border = '3px solid red';
  }

});