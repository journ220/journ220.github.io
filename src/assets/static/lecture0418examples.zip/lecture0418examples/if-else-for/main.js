// button
const toggleBorder = document.getElementById('toggleBorder');

// all the images with the class "outline"
const outlineImages = document.getElementsByClassName('outline');

// upon load, the images so far have not been toggled
let toggled = false;

toggleBorder.addEventListener('click', function(e) {
  // when the button is clicked
  
  // iterate over every element in outlineImages
  for (let i=0; i < outlineImages.length; i++) {
    // if toggled is true
    if (toggled) {
      // then remove the border
      outlineImages[i].style.border = '';
    } else {
      // if toggled is false
      // then add a red border
      outlineImages[i].style.border = '3px solid red';
    }
  }

  // "flip" the toggle
  if (toggled) {
    toggled = false;
  } else {
    toggled = true;
  }
});