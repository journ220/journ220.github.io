// button
const checkButton = document.getElementById('checkButton');
const ageInput = document.getElementById('age');
const ageCheck = document.getElementById('ageCheck');
const driveInput = document.getElementById('driveCheck');
const voteInput = document.getElementById('voteCheck');

checkButton.addEventListener('click', function(e) {

  // get value of input
  const age = ageInput.value;
  ageCheck.innerHTML = age;

  if (age >= 16) {
    driveInput.innerHTML = 'YES'
  } else {
    driveInput.innerHTML = 'NO'
  }

  if (age >= 18) {
    voteInput.innerHTML = 'YES'
  } else {
    voteInput.innerHTML = 'NO'
  }

  // try writing code to check for legal age of drinking
});