// works regardless of when script is loaded
const docReady = function (fn) {
  // see if DOM is already available
  if (document.readyState === "complete" || document.readyState === "interactive") {
    // call on next available tick
    setTimeout(fn, 1);
  } else {
    document.addEventListener("DOMContentLoaded", fn);
  }
};

docReady(function () {
  console.log("docReady");

  // when you click on the "Change h1" button
  const h1Button = document.getElementById("change-h1");
  h1Button.addEventListener("click", function () {
    console.log("change h1");
    document.querySelector("h1").style.color = "red";
  });

  // when you click on the "Change h2s" button
  const h2Button = document.getElementById("change-h2s");
  h2Button.addEventListener("click", function () {
    document.querySelectorAll("h2").style.color = "blue"; // this will not work!

    // The following code will not run unless you comment out the code above
    document.querySelectorAll("h2").forEach(function (element, index) {
      // looping
      if (index == 0) {
        element.style.color = "yellow";
      } else if (index % 2) {
        element.style.color = "blue";
      } else {
        element.style.color = "green";
      } // no semicolon at the end of if/else block
    });
  });
});
