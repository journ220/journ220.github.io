// works better when script is set to 'defer'
document.addEventListener(
  "DOMContentLoaded",
  function () {
    // your code goes here
    console.log("DOMContentLoaded");
  },
  false
);
