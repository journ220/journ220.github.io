// works regardless of when script is loaded
const docReady = function (fn) {
  // see if DOM is already available
  if (document.readyState === "complete" || document.readyState === "interactive") {
    // call on next available tick
    setTimeout(fn, 1);
  } else {
    document.addEventListener("DOMContentLoaded", fn);
  }
};

const randomIntFromInterval = function (min, max) {
  // min and max included
  return Math.floor(Math.random() * (max - min + 1) + min);
};

const predictions = [
  // there are 20 options here
  "It is certain",
  "It is decidedly so",
  "Without a doubt",
  "Yes definitely",
  "You may rely on it",
  "As I see it, yes",
  "Most likely",
  "Outlook good",
  "Yes",
  "Signs point to yes",
  "Reply hazy, try again",
  "Ask again later",
  "Better not tell you now",
  "Cannot predict now",
  "Concentrate and ask again",
  "Don't count on it",
  "My reply is no",
  "My sources say no",
  "Outlook not so good",
  "Very doubtful",
];

docReady(function () {
  const predictButton = document.getElementById("predict");

  predictButton.addEventListener("click", function () {
    // get a random number from 0 to 19
    const randomSelection = randomIntFromInterval(0, 19);
    // how can we make the above code work regardless of how many options are in the
    // `predictions` array?

    // pick a random prediction using index
    const predictionText = predictions[randomSelection];

    // fill the "prediction" paragraph element with the text from the prediction
    document.getElementById("prediction").innerText = predictionText;
  });
});
